from flask import Flask, render_template

app = Flask(__name__)


@app.route('/')
def hello():
    return '<p>Ganesh </p>'@app.route('/klu')
def kl():
    return render_template('klu.html')